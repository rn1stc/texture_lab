import csv
import os
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import glob
import shutil

shutil.rmtree('avg_img')
shutil.rmtree('avg_txt')
list_avg = ['_eulerangles', '_f', '_p', '_resistance_slip', '_shearrate_slip','_resolvedstress_slip',
            '_resistance_twin', '_shearrate_twin', '_resolvedstress_twin', '_resistance', '_shearrate', '_resolvedstress']
dataavg = list()
lst = os.listdir('.')
lst.sort()
h = len(glob.glob1('.',"*.txt"))
for filename in lst:
    if filename.endswith('.txt'):
        with open(filename, 'rt') as f:
            next(f)
            next(f)
            next(f)
            next(f)
            reader = csv.reader(f, delimiter='	', skipinitialspace=True)

            cols = next(reader)
            w = len(cols)
            print(cols)
            data = np.zeros(w, dtype=np.float32)
            i = 1

            for line in reader:
                data = data + np.asarray([float(k) if k != 'n/a' else 1 for k in line])
                i = i + 1

            data = data / ( i - 1 )
            dataavg.append(data)

print(dataavg)
x = range(1,h)
os.makedirs('avg_img')
os.makedirs('avg_txt')
os.system('pwd > tmp')
path = open('tmp', 'r').read()
dir_name = path[15:-10]
for i in range(0, len(cols)):
    out_file = open("avg_txt/" + dir_name + "_" + cols[i] + '.dat', 'w')
    y = list()
    for j in range(0, h-1):
        y.append(dataavg[j][i])
        out_file.write("%e\n" % (dataavg[j][i]))
    out_file.close()
    plt.plot(x, y, '-o')
    plt.ylabel(cols[i])
    #plt.savefig("avg_img/" + dir_name + "_" + cols[i] + ".png")
    plt.close()

linestyles = ('-o','--o','-.o',':o','-s','--s','-.s',':s','-^','--^','-.^',':^')
ll = 0
for avgname in list_avg:
    plt.figure(figsize=(10, 5))
    ax = plt.subplot(121)  # <- with 2 we tell mpl to make room for an extra subplot
    for i in range(0, len(cols)):
        if avgname in cols[i]:
            y = list()
            for j in range(0, h - 1):
                y.append(dataavg[j][i])
            ax.plot(x, y, linestyles[ll%12], label=cols[i])
            ll += 1
            plt.ylabel(avgname)

    ax.legend(bbox_to_anchor=(1.05, 1), loc=2, borderaxespad=0., prop={'size': 10})
    plt.show()
    #plt.savefig("avg_img/" + dir_name + "_0COMPARE" + avgname + ".png", dpi=96)
    plt.close()

k=0
comb_matrix_slip = [3, 3, 12]
comb_matrix_twin = [6, 6, 6]
list_comb = ['_resistance_', '_shearrate_','_resolvedstress_']

for combname in list_comb:
    ll = 0
    k = 0
    plt.figure(figsize=(10, 5))
    ax = plt.subplot(121)  # <- with 2 we tell mpl to make room for an extra subplot
    for comb_len in comb_matrix_slip:
        z = list()
        for j in range(1, comb_len+1):
            kj = k + j
            for i in range(0, len(cols)):
                if str(kj)+combname+'slip' == cols[i]:
                    print(str(kj)+combname+'slip')
                    y = list()
                    for jj in range(0, h - 1):
                        y.append(dataavg[jj][i])
                    break
            if len(z) == 0:
                z = y
            else:
                z = [sum(xx) for xx in zip(z, y)]
        ax.plot(x, z, linestyles[ll % 12], label=str(comb_len)+'_'+combname+'slip')
        ll += 1
        plt.ylabel(combname+'slip')
        k += comb_len
    ax.legend(bbox_to_anchor=(1.05, 1), loc=2, borderaxespad=0., prop={'size': 10})
    plt.savefig("avg_img/" + dir_name + "_0COMBINED" + combname + ".png", dpi=96)
    plt.close()