import csv
import os
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import glob

dataavg = list()
lst = os.listdir('.')
lst.sort()
h = len(glob.glob1('.',"*.txt"))
for filename in lst:
    if filename.endswith('.txt'):
        with open(filename, 'rt') as f:
            next(f)
            next(f)
            next(f)
            next(f)
            reader = csv.reader(f, delimiter='	', skipinitialspace=True)

            cols = next(reader)
            w = len(cols)
            print(cols)
            data = np.zeros(w, dtype=np.float32)
            i = 1

            for line in reader:
                data = data + np.asarray([float(k) if k != 'n/a' else 1 for k in line])
                i = i + 1

            data = data / ( i - 1 )
            dataavg.append(data)

print(dataavg)
x = range(1,h)
os.makedirs('img')
for i in range(0, len(cols)):
    y = list()
    for j in range(0, h-1):
        y.append(dataavg[j][i])
    plt.plot(x, y, '-o')
    plt.ylabel(cols[i])
    plt.savefig("img/" + cols[i] + ".png")
    plt.close()
