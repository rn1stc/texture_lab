# -*- coding: UTF-8 no BOM -*-
#
# Copyright 2011-16 Max-Planck-Institut für Eisenforschung GmbH
# 
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# 
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

"""Main aggregator"""
import sys, os

with open(os.path.join(os.path.dirname(__file__),'../../VERSION')) as f:
  version = f.readline()[:-1]

from .environment import Environment      # noqa
from .asciitable  import ASCIItable       # noqa
from .config      import Material         # noqa
from .colormaps   import Colormap, Color  # noqa
from .orientation import Quaternion, Rodrigues, Symmetry, Orientation # noqa
# try:
#     from .corientation import Quaternion, Rodrigues, Symmetry, Orientation
#     print "Import Cython version of Orientation module"
# except:
#     from .orientation import Quaternion, Rodrigues, Symmetry, Orientation
#from .block       import Block           # only one class
from .result      import Result           # noqa
from .geometry    import Geometry         # noqa
from .solver      import Solver           # noqa
from .test        import Test             # noqa
from .util        import extendableOption # noqa

try:
  from .          import core
# cleaning up namespace
###################################################################################################
# capitalize according to convention
  core.IO                            = core.io
  core.FEsolving                     = core.fesolving
  core.DAMASK_interface              = core.damask_interface
# remove modulePrefix_
  core.prec.init                     = core.prec.prec_init
  core.DAMASK_interface.init         = core.DAMASK_interface.DAMASK_interface_init
  core.IO.init                       = core.IO.IO_init
  core.numerics.init                 = core.numerics.numerics_init
  core.debug.init                    = core.debug.debug_init
  core.math.init                     = core.math.math_init
  core.math.tensorAvg                = core.math.math_tensorAvg
  core.FEsolving.init                = core.FEsolving.FE_init
  core.mesh.init                     = core.mesh.mesh_init
  core.mesh.nodesAroundCentres       = core.mesh.mesh_nodesAroundCentres
  core.mesh.deformedCoordsFFT        = core.mesh.mesh_deformedCoordsFFT
  core.mesh.volumeMismatch           = core.mesh.mesh_volumeMismatch
  core.mesh.shapeMismatch            = core.mesh.mesh_shapeMismatch

except (ImportError,AttributeError) as e:
  core = None # from http://www.python.org/dev/peps/pep-0008/
  if os.path.split(sys.argv[0])[1] not in ('symLink_Processing.py',
                                           'compile_CoreModule.py',
                                          ):
    sys.stderr.write('\nWARNING: Core module (Fortran code) not available, \n'\
                     "try to run 'make processing'\n"\
                     'Error message when importing core.so: %s\n\n'%e)
