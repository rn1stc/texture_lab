# -*- coding: UTF-8 no BOM -*-
#
# Copyright 2011-16 Max-Planck-Institut für Eisenforschung GmbH
# 
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# 
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

# $Id$

import os,subprocess,shlex

class Environment():
  __slots__ = [ \
                'rootRelation',
                'options',
              ]

  def __init__(self,rootRelation = '.'):
    self.rootRelation = rootRelation
    self.options = {}
    self.get_options()

  def relPath(self,relative = '.'):
    return os.path.join(self.rootDir(),relative)

  def rootDir(self):
    return os.path.normpath(os.path.join(os.path.realpath(__file__),'../../../'))

  def get_options(self):
    if os.path.isfile(os.path.join(os.getenv('HOME'),'.damask/damask.conf')):
      configFile = os.path.join(os.getenv('HOME'),'.damask/damask.conf')
    else:
      configFile = '/etc/damask.conf'
    with open(self.relPath(configFile)) as file:
      for line in file:
        l = line.strip()
        if not (l.startswith('#') or l == ''):
          items = l.split('=') + ['','']
          if items[1] != '':                                # nothing specified
            self.options[items[0].upper()] = items[1]
      
  def isAvailable(self,software,Nneeded =-1):
    licensesNeeded = {'abaqus'  :5,
                      'standard':5,
                      'explicit':5}
    if Nneeded == -1: Nneeded = licensesNeeded[software]
    try:
      cmd = """ ssh mulicense2 "/Stat_Flexlm | grep 'Users of %s: ' | cut -d' ' -f7,13" """%software
      process = subprocess.Popen(shlex.split(cmd),stdout = subprocess.PIPE,stderr = subprocess.PIPE)
      licenses = map(int, process.stdout.readline().split())
      try:
        if licenses[0]-licenses[1] >= Nneeded:
          return 0
        else:
          print('%s missing licenses for %s'%(licenses[1] + Nneeded - licenses[0],software))
          return licenses[1] + Nneeded - licenses[0]
      except IndexError:
        print('Could not retrieve license information for %s'%software)
        return 127
    except:
      return 126
